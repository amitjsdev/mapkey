import logo from './logo.svg';
import './App.css';
import MapKey from './components/MapKey'
function App() {
  return (
    <div className="App">
      <MapKey/>
    </div>
  );
}

export default App;

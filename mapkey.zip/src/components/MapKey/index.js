import React from 'react';
import './index.css';

function MapKey() {

    //declare map
    let mapData = new Map([
        ['cucumber', 500],
        ['tomatoes', 350],
        ['onion', 50]
    ]);

      // map data key added in array

    let finalMapData = []

    for (let mapKey of mapData.keys()) {
        finalMapData.push(mapKey)

    }
  
    console.log("finalMapData", finalMapData);


    //put keys in array
    let keys = Array.from(mapData.keys());
    console.log("keys", keys);


    //another method for put key in array
    let keys2 = [...mapData.keys()];

    console.log("keys2", keys2);


    //get key values from object 
    let objectData = { 'first': "one", 'second': "two", 'third': "three", 'fourth': "four" };
    console.log('Object', Object.keys(objectData));

    let listData = ["one","two","three","four"];

    return (
        <div className="App">
            {/* Assign key to the listing */}
            <h3>Map listing with key</h3>
            <ul>
                {
                    listData && listData.length > 0 && listData.map((item,i) => {
                        return (
                           <li className="liNone" key={i}>{item}</li>

                        )
                    }
                    )
                }
            </ul>

        </div>
    );
}

export default MapKey;
